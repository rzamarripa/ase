<table class="table table-bordered table-striped">
	<thead class="thead">
		<tr>
			<td class='span2'>
			    <b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?></b>
		    </td>
		    <td >
			    <b><?php echo CHtml::encode($data->getAttributeLabel('nombre')); ?></b>
		    </td>
		    <td >
			    <b><?php echo CHtml::encode($data->getAttributeLabel('requisicion')); ?></b>
		    </td>
		    <td >
			    <b><?php echo CHtml::encode($data->getAttributeLabel('cotizacion')); ?></b>
		    </td>
		</tr>
	</thead>
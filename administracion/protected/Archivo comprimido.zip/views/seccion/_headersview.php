<table class="table table-bordered table-striped">
	<thead class="thead">
		<tr>
			<td class='col-xs-2'>
				<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?></b>
			</td>
			<td >
				<b><?php echo CHtml::encode($data->getAttributeLabel('nombre')); ?></b>
			</td>
			<td >
				<b><?php echo CHtml::encode($data->getAttributeLabel('estatus_did')); ?></b>
			</td>
			<td class="col-xs-2">
				<b>Acciones</b>
			</td>
		</tr>
	</thead>